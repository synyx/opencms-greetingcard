/*
 * This file is part of the Synyx Greetingcard module for OpenCms.
 *
 * Copyright (c) 2007 Synyx GmbH & Co.KG (http://www.synyx.de)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.synyx.greetingcard;

import java.awt.Image;
import java.awt.image.RenderedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import org.opencms.file.CmsObject;
import org.opencms.file.types.CmsResourceTypeImage;
import org.opencms.jsp.CmsJspActionElement;
import org.opencms.jsp.CmsJspTagContentLoad;
import org.opencms.jsp.CmsJspTagContentLoop;
import org.opencms.jsp.CmsJspXmlContentBean;
import org.opencms.main.CmsException;

/**
 * @author Rainer Steinegger, Synyx GmbH & Co. KG
 * @author Florian Hopf, Synyx GmbH & Co. KG
 */
public class ShowPreviewBean {
    
    private boolean sendNow;
    private boolean isDateInPast;
    private boolean isTooManyDays;
    private String url;
    private int dateDay;
    private int dateMonth;
    private int dateYear;
    private int dateHour;
    private int dateMinute;
    private String authorAddress;
    private String receiverAddress;
    private String subject;
    private String authorName;
    private String receiverName;
    private String resourceName;
    
    private long transmitTime;
    
    public void init(PageContext context, HttpServletRequest request, HttpServletResponse response) throws Exception {
        sendNow = (request.getParameter("sendNow") != null && request.getParameter("sendNow").equals("0")) ;
        // check if the entered date is valid, if not, the user has a second chance to enter it, either the mail becomes send the next possible date
        // get the entered date from the request
        dateDay = Integer.parseInt(request.getParameter("date_day"));
        dateMonth = Integer.parseInt(request.getParameter("date_month"));
        dateYear = Integer.parseInt(request.getParameter("date_year"));
        dateHour = Integer.parseInt(request.getParameter("date_hour"));
        dateMinute = Integer.parseInt(request.getParameter("date_minute"));

        // get the amount days for the selected year and month
        int daysOfTheMonth = GreetingCardHelper.getAmountDays(getDateMonth(), getDateYear());

        Calendar calendar = Calendar.getInstance();
        //calendar.setTimeZone(TimeZone.getTimeZone("Europe/Berlin"));
        long currentLong = calendar.getTimeInMillis();
        calendar.set(Calendar.HOUR_OF_DAY, getDateHour());
        calendar.set(Calendar.MINUTE, getDateMinute());	
        calendar.set(Calendar.DATE, getDateDay());
        calendar.set(Calendar.MONTH, getDateMonth() - 1);
        calendar.set(Calendar.YEAR, getDateYear());
        transmitTime = calendar.getTimeInMillis();

        isDateInPast =!isSendNow() && transmitTime < currentLong;
        isTooManyDays = !isSendNow() && getDateDay() > daysOfTheMonth;
        
        if (!isIsDateInPast() && !isIsTooManyDays()) {
            createCard(context, request, response);
        }
    }
    
    public boolean isDateInPast() {
        return isIsDateInPast();
    }
    
    public boolean isTooManyDays() {
        return isIsTooManyDays();
    }
    
    private void createCard(PageContext context, HttpServletRequest request, HttpServletResponse response) throws Exception {
            final int resourceTypeImage = CmsResourceTypeImage.getStaticTypeId();
        CmsJspXmlContentBean content = new CmsJspXmlContentBean(context, request, response);
        CmsObject cmsObject = content.getCmsObject();
        Locale currentLocale = cmsObject.getRequestContext().getLocale();

        // the text is send by the parameter text0, text1, .. depending on how much textfields are available
        // this text fields are reveived now
        int whichTextField = 0;
        List text = new ArrayList();  
        while (request.getParameter("text" + whichTextField) != null) {
            text.add(request.getParameter("text" + whichTextField));
            whichTextField++;
        } 
        // to get the text informations its necessary to know the path of the xml content
        String xmlContent = request.getParameter("greetingcard_fileName");

        //get the parameters from the request
        authorName = request.getParameter("author_name");
        authorAddress = request.getParameter("author_address");
        receiverName = request.getParameter("receiver_name");
        if (request.getParameter("receiver_address") != null) {
            receiverAddress = request.getParameter("receiver_address");
        } else {
            receiverAddress = request.getParameter("receiver_address_whitelist") + "@" + request.getParameter("receiver_domain");
        }    
        subject = request.getParameter("subject"); 

        // first get the content of the configuration xml-file to configure the url
        CmsJspTagContentLoad configurationContentList = (CmsJspTagContentLoad) content.contentload("singleFile", 
                cmsObject.getRequestContext().removeSiteRoot("/sites/default/greetingcards/configuration"), false);
        configurationContentList.hasMoreContent();

        CmsJspTagContentLoop databaseContentList = (CmsJspTagContentLoop)content.contentloop(configurationContentList, "Database");
        databaseContentList.hasMoreContent();
        //String serverUrl = content.contentshow(configurationContentList, "ServerUrl", currentLocale);

        String path = content.link(content.getContent(xmlContent, "Image", currentLocale));

        // generate the picture and initialize an instance of the image creater class for adding the received text to the picture
        String newUrl = "";
        String pictureFileName = GreetingCardHelper.getServerPath(request, path);
        Image backgroundImage = ImageIO.read(new URL(pictureFileName));
        ImageCreator imageCreator = new ImageCreator(backgroundImage, getAuthorName(), getReceiverName());    
        // add all textes to the picture
        Iterator textIterator = text.iterator();    
        // first get the wohle content of the single xml-file
        CmsJspTagContentLoad contentList = (CmsJspTagContentLoad) content.contentload("singleFile", xmlContent, false);
        // this call is needed to get the content
        contentList.hasMoreContent();            
        // get all text fields of the xml-file              
        CmsJspTagContentLoop textfieldContentList = (CmsJspTagContentLoop)content.contentloop(contentList, "TextField");
        // iterate over all textfields (this call is also needed to get the content)
        while (textfieldContentList.hasMoreContent()) {
            String currentText = (String)textIterator.next();  
            String fontColor = content.contentshow(textfieldContentList, "FontColor", currentLocale); 
            String fontType = content.contentshow(textfieldContentList, "FontType", currentLocale); 
            int fontSize = Integer.parseInt(content.contentshow(textfieldContentList, "FontSize", currentLocale)); 
            int pictureTopX = Integer.parseInt(content.contentshow(textfieldContentList, "PictureTop-X", currentLocale)); 
            int pictureTopY = Integer.parseInt(content.contentshow(textfieldContentList, "PictureTop-Y", currentLocale)); 
            int pictureBottomX = Integer.parseInt(content.contentshow(textfieldContentList, "PictureBottom-X", currentLocale)); 
            int pictureBottomY = Integer.parseInt(content.contentshow(textfieldContentList, "PictureBottom-Y", currentLocale)); 
            String [] fontStyles = {content.contentshow(textfieldContentList, "FontItalic", currentLocale), content.contentshow(textfieldContentList, "FontBold", currentLocale), content.contentshow(textfieldContentList, "FontUnderline", currentLocale), content.contentshow(textfieldContentList, "FontPlain", currentLocale)};
            imageCreator.addText(pictureTopX, pictureTopY, pictureBottomX, pictureBottomY, currentText, fontSize, fontColor, fontStyles, fontType);      
        }               

        // get the generated image from the image creater and save it
        RenderedImage newPicture = (RenderedImage) imageCreator.getFile();
        // the image creater class also handles the new filename (with the path) of the picture to save at
        newUrl = cmsObject.getRequestContext().removeSiteRoot(imageCreator.getNewLocation());    

        String con = content.contentshow(databaseContentList, "DatabaseUrl", currentLocale);
        String tableField = content.contentshow(databaseContentList, "ColumnName", currentLocale);
        String tableName = content.contentshow(databaseContentList, "TableName", currentLocale);
        String user = content.contentshow(databaseContentList, "DatabaseUser", currentLocale);
        String pass = content.contentshow(databaseContentList, "DatabasePassword", currentLocale);

        boolean internal = GreetingCardHelper.isInternal(getReceiverAddress(), con, tableField, tableName, user, pass);

        GreetingCardHelper.writeImage(cmsObject, newPicture, newUrl, internal);
        
        resourceName = newUrl + ".png";
        url = content.link(resourceName);

    }

    public boolean isSendNow() {
        return sendNow;
    }

    public boolean isIsDateInPast() {
        return isDateInPast;
    }

    public boolean isIsTooManyDays() {
        return isTooManyDays;
    }

    public String getUrl() {
        return url;
    }

    public int getDateDay() {
        return dateDay;
    }

    public int getDateMonth() {
        return dateMonth;
    }

    public int getDateYear() {
        return dateYear;
    }

    public int getDateHour() {
        return dateHour;
    }

    public int getDateMinute() {
        return dateMinute;
    }

    public String getAuthorAddress() {
        return authorAddress;
    }

    public String getReceiverAddress() {
        return receiverAddress;
    }

    public String getSubject() {
        return subject;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public long getTransmitTime() {
        return transmitTime;
    }

    public String getResourceName() {
        return resourceName;
    }
}
