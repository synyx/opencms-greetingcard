/*
 * This file is part of the Synyx Greetingcard module for OpenCms.
 *
 * Copyright (c) 2007 Synyx GmbH & Co.KG (http://www.synyx.de)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.synyx.greetingcard;

import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import org.opencms.file.CmsObject;
import org.opencms.jsp.CmsJspActionElement;
import org.opencms.jsp.CmsJspTagContentLoad;
import org.opencms.jsp.CmsJspTagContentLoop;
import org.opencms.jsp.CmsJspXmlContentBean;
import org.opencms.loader.CmsImageScaler;
import org.opencms.main.CmsException;

/**
 * Bean for use in chooseImage.jsp.
 * @author Rainer Steinegger, Synyx GmbH & Co. KG
 * @author Florian Hopf, Synyx GmbH & Co. KG
 */
public class ChooseImageBean {
    
    private List subFolders;
    private List images;
    private int height;
    private int width;
    private int quality;
    private int xmlId;
    private String resourceName;
    private CmsJspActionElement jsp;
    private CmsImageScaler scaler;
    private Locale locale;
    
    /** Creates a new instance of ChooseImageBean */
    public ChooseImageBean() {
    }
    
    public void init(PageContext context, HttpServletRequest request, HttpServletResponse response) throws JspException, CmsException {

        // first get the content of the configuration xml-file
        CmsJspXmlContentBean content = new CmsJspXmlContentBean(context, request, response);
        jsp = content;
        CmsObject cmsObject = content.getCmsObject();
        CmsJspTagContentLoad contentList = (CmsJspTagContentLoad) 
            content.contentload("singleFile", 
                cmsObject.getRequestContext().removeSiteRoot("/sites/default/greetingcards/configuration"), false);
        contentList.hasMoreContent();

        // get all text fields of the xml-file              
        CmsJspTagContentLoop thumbnailContentList = (CmsJspTagContentLoop)content.contentloop(contentList, "Thumbnail");
        // iterate over all textfields (this call is also needed to get the content)
        thumbnailContentList.hasMoreContent();

        // used constants within this jsp
        locale = cmsObject.getRequestContext().getLocale();
        height = Integer.parseInt(content.contentshow(thumbnailContentList, "ThumbnailHeight", locale));
        width = Integer.parseInt(content.contentshow(thumbnailContentList, "ThumbnailWidth", locale));
        xmlId = Integer.parseInt(content.contentshow(thumbnailContentList, "XMLID", locale));
        // the quality of the imag to be saved in percent
        quality = Integer.parseInt(content.contentshow(thumbnailContentList, "ThumbnailQuality", locale));

        // initialize the default name of the current folder
        resourceName = cmsObject.getRequestContext().removeSiteRoot("/sites/default/greetingcards/content/");
        if (request.getParameter("greetingcard_path") != null) {
            // if there is a request of a selected folder, the new name of the current folder is set
            resourceName = request.getParameter("greetingcard_path");
        }    

        // if there are more subfolders, put them into the list and display them at the while-loop
        subFolders = content.getNavigation().getNavigationForFolder(resourceName);

        // get the files in this folder
        images = cmsObject.getFilesInFolder(resourceName);

        scaler = new CmsImageScaler();
        scaler.setHeight(getImageHeight());
        scaler.setWidth(getImageWidth());
        scaler.setQuality(getImageQuality());
    }

    public String getResourceName() {
        return resourceName;
    }
    
    public List getSubFolders() {
        return subFolders;
    }

    public List getImages() {
        return images;
    }
    
    public int getImageHeight() {
        return height;
    }
    
    public int getImageWidth() {
        return width;
    }
    
    public int getXmlContentId() {
        return xmlId;
    }
    
    public int getImageQuality() {
        return quality;
    }
    
    public CmsJspActionElement getJsp() {
        return jsp;
    }
    
    public CmsImageScaler getScaler() {
        return scaler;
    }
    
    public Locale getLocale() {
        return locale;
    }
}
