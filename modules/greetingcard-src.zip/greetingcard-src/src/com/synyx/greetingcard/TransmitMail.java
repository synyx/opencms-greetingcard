/*
 * This file is part of the Synyx Greetingcard module for OpenCms.
 *
 * Copyright (c) 2007 Synyx GmbH & Co.KG (http://www.synyx.de)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.synyx.greetingcard;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.commons.logging.Log;
import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsProject;
import org.opencms.file.CmsProperty;
import org.opencms.file.CmsResourceFilter;
import org.opencms.mail.CmsMailHost;
import org.opencms.mail.CmsVfsDataSource;
import org.opencms.main.CmsException;
import org.opencms.main.CmsLog;
import org.opencms.main.OpenCms;
import org.opencms.scheduler.I_CmsScheduledJob;
import org.synyx.opencms.tools.FindMaster;


/*
 * TransmitMail.java
 *
 * Created on 14. Oktober 2006, 11:38
 *
 */

/**
 * This class is used by the greetingcards opencms modul. It becomes by the method sendMail(...)
 * the needed parameters and submits the mail, when the server has enough resources and the
 * time parameter is reached.
 *
 * @author Rainer Steinegger, Synyx GmbH & Co. KG, steinegger@synyx.de
 * @author Florian Hopf, Synyx GmbH & Co. KG, hopf@synyx.de
 * @author <a href="mailto:daniel@synyx.de"Markus Daniel</a> Synyx GmbH & Co. KG Karlsruhe, Germany
 *			<li>check if this is the master host before launching the scheduled job</li>
 */
public class TransmitMail implements I_CmsScheduledJob {
	
	private static final Log log = CmsLog.getLog(TransmitMail.class);
	
	/**
	 * This constant saves the text of the mail.
	 */
	private final static String SENDTEXT = "Eine Gru&szlig;karte f&uuml;r Sie !";
	/**
	 * This constant represents a html break line.
	 */
	private final static String BREAKLINE = "<br />";
	/**
	 * This constant saves the beginning of the sended href of the image as a string.
	 */
	private final static String HREFLEFT = "Die Gru&szlig;karte k&ouml;nnen Sie <a href=\"";
	/**
	 * This constant saves the end of the sended href of the image as a string.
	 */
	private final static String HREFRIGHT = "\">hier</a> ansehen.";
	
	/**
	 * This variable is written into the opencms log after beeing started.
	 */
	private final static String LOG = "Synyx Greeting Card modul sent mails.";
	
	/**
	 * This variable is written into the opencms log after beeing started.
	 */
	private final static String QUEUEFOLDER = "/sites/default/greetingcards/MailsToSend/";
	
	/**
	 * This variable is written into the opencms log after beeing started.
	 */
	private final static String ARCHIVEFOLDER = "/sites/default/greetingcards/archive/";
	
	/**
	 * The default constructor is not neccessary because the needed method sendMail is static.
	 */
	public TransmitMail() {
	}
	
	/**
	 * This method gets - by transmitting a mail with the greetingcards modul - the needed parameters.
	 * Then it creates a new mail and adds the file as an attachment or sends the url of the new file.
	 *
	 *
	 * @return True if the message was created succesfully, else false.
	 * @param archiveUrl the complete, accessible path to the greeting card
	 * @param sendDate The date when the mail should be sent.
	 * @param sendImage If true the image will be attached, either the url will be send at the mail.
	 * @param fileToSend The image as a CmsFile.
	 * @param cmsObject The cms object to send the mail.
	 * @param author_name The author name of the new mail.
	 * @param author_address The author mail-address of the new mail.
	 * @param receiver_name The receiver name of the mail.
	 * @param receiver_address The receiver mail-address of the mail.
	 * @param subject The subject of the mail.
	 */
	public static boolean sendMail(String author_name, String author_address,
		String receiver_name, String receiver_address, String subject,
		CmsFile fileToSend, String archiveUrl,
		CmsObject cmsObject, String sendDate, boolean sendImage) {
		
		boolean ok = false;
		
		long dateAsLong = Long.parseLong(sendDate);
		if (dateAsLong == 0) {
			// the mail will be sent now
			try {
				if (sendImage) {
					// the mail is sent to extern and so the greetingcard becomes attached
					/*CmsMultiPartMail multiMail = new CmsMultiPartMail();
					multiMail.setFrom(author_address, author_name);
					multiMail.setSubject(subject);
					multiMail.addTo(receiver_address, receiver_name);
					multiMail.setMsg(SENDTEXT);*/
					CmsVfsDataSource dataSource = new CmsVfsDataSource(cmsObject, fileToSend);
					/*multiMail.attach(dataSource, IMAGEFILENAME, IMAGEDESCRIPTION);
					CmsMailTransport transport = new CmsMailTransport(multiMail);
					transport.send();*/
					sendMultipartMail(author_address, author_name, receiver_address, receiver_name, subject,
						"", dataSource, fileToSend.getName());
					ok = true;
				} else {
					// if the mail is sent intern,  the url to the greeting card is only submitted
					/*CmsHtmlMail simpleMail = new CmsHtmlMail();
					simpleMail.setFrom(author_address, author_name);
					simpleMail.setSubject(subject);
					simpleMail.addTo(receiver_address, receiver_name);
					simpleMail.setMsg(SENDTEXT + BREAKLINE + HREFLEFT + archiveUrl.substring(0, archiveUrl.length()-2)
							+ fileToSend.getRootPath() + HREFRIGHT);*/
					
					/*CmsMultiPartMail simpleMail = new CmsMultiPartMail();
					 
					simpleMail.setFrom(author_address, author_name);
					simpleMail.setSubject(subject);
					simpleMail.addTo(receiver_address, receiver_name);
					simpleMail.setMsg(SENDTEXT + BREAKLINE + HREFLEFT + archiveUrl
							+ HREFRIGHT);
					simpleMail.
					CmsMailTransport transport = new CmsMailTransport(simpleMail);
					transport.send();*/
					sendMail(author_address, author_name, receiver_address, receiver_name,
						subject, SENDTEXT + BREAKLINE + HREFLEFT + archiveUrl
						+ HREFRIGHT);
					ok = true;
				}
				// send the mail now
			} catch (Exception ex) {
				log.error("", ex);
				ok = false;
			}
		} else {
			// the mail should be sent later, so the new image will be moved at the "toSend"-folder
			// and the needed properties for the trasmition are attached as fileproperties.
			addMailToQueue(author_name, author_address, receiver_name, receiver_address
				, subject, dateAsLong, fileToSend, archiveUrl, cmsObject, sendImage);
			ok = true;
		}
		
		return ok;
	}
	
	/**
	 * This methods inserts the new mail into the list. At the schedule job,
	 * theses mails will be send.
	 *
	 * @param serverUrl The url of the used server.
	 * @param transmit_time The time when the mail should be sent.
	 * @param sendImage If true the image will be attached, either the url will be send at the mail.
	 * @param fileToSend The image as a CmsFile.
	 * @param author_name The author name of the new mail.
	 * @param author_address The author mail-address of the new mail.
	 * @param receiver_name The receiver name of the mail.
	 * @param receiver_address The receiver mail-address of the mail.
	 * @param subject The subject of the mail.
	 */
	private static void addMailToQueue(String author_name, String author_address,
		String receiver_name, String receiver_address, String subject
		, long transmit_time, CmsFile fileToSend, String archiveUrl
		, CmsObject cmsObject, boolean sendImage) {
		String imageUrl = cmsObject.getSitePath(fileToSend);
		//CmsSystemConfiguration systemConfiguration = new CmsSystemConfiguration();
		String name = fileToSend.getName();
		try {
			boolean online = GreetingCardHelper.setProjectOffline(cmsObject);
			
			String newUrl = cmsObject.getRequestContext().removeSiteRoot(QUEUEFOLDER + name);
			cmsObject.lockResource(imageUrl);
			ArrayList propertyList = new ArrayList();
			
			CmsProperty prop1 = new CmsProperty("greetingCardTransmitTime", String.valueOf(transmit_time), String.valueOf(transmit_time));
			propertyList.add(prop1);
			CmsProperty prop2 = new CmsProperty("greetingCardAuthorName", author_name, author_name);
			propertyList.add(prop2);
			CmsProperty prop3 = new CmsProperty("greetingCardAuthorAddress", author_address, author_address);
			propertyList.add(prop3);
			CmsProperty prop4 = new CmsProperty("greetingCardReceiverName", receiver_name, receiver_name);
			propertyList.add(prop4);
			CmsProperty prop5 = new CmsProperty("greetingCardReceiverAddress", receiver_address, receiver_address);
			propertyList.add(prop5);
			CmsProperty prop6 = new CmsProperty("greetingCardSubject", subject, subject);
			propertyList.add(prop6);
			CmsProperty prop7 = new CmsProperty("greetingCardArchiveUrl", archiveUrl, archiveUrl);
			propertyList.add(prop7);
			CmsProperty prop8 = new CmsProperty("greetingCardSendImage", String.valueOf(sendImage), String.valueOf(sendImage));
			propertyList.add(prop8);
			
			//cmsObject.writePropertyObjects(imageUrl, propertyList);
			for (Iterator it = propertyList.iterator(); it.hasNext(); ) {
				cmsObject.writePropertyObject(imageUrl, (CmsProperty) it.next());
				
			}
			cmsObject.moveResource(imageUrl, newUrl);
			cmsObject.unlockResource(imageUrl);
			cmsObject.publishResource(newUrl);
			cmsObject.publishResource(imageUrl);
			if (online) {
				cmsObject.getRequestContext().setCurrentProject(cmsObject.readProject(CmsProject.ONLINE_PROJECT_ID));
			}
			
		} catch (CmsException ex) {
			OpenCms.getLog(TransmitMail.class).error("", ex);
		} catch (Exception ex) {
			OpenCms.getLog(TransmitMail.class).error("", ex);
		}
	}
	
	/**
	 * This method traverses the elements of the array list and returns the mails,
	 * which are now able to send (time of mail < currentTime).
	 *
	 * @param currentTime The time of the system.
	 * @return The elements which are now able to send (time of mail < currentTime).
	 */
	private List getElementsToSend(long currentTime, CmsObject cmsObject) {
		List elementsToSend = new ArrayList();
		List allResources;
		// we only want to notice slight differences, so we use seconds instead of ms
		long currentSeconds = currentTime/1000 + 60;
		try {
			allResources = (List) cmsObject.getResourcesInFolder(cmsObject.getRequestContext().removeSiteRoot(QUEUEFOLDER), CmsResourceFilter.ALL);
			Iterator resourceIterator = allResources.iterator();
			boolean online = GreetingCardHelper.setProjectOffline(cmsObject);
			while (resourceIterator.hasNext()) {
				CmsFile currentImage = (CmsFile) resourceIterator.next();
				String imageUrl = cmsObject.getSitePath(currentImage);
				String newUrl = cmsObject.getRequestContext().removeSiteRoot(ARCHIVEFOLDER + currentImage.getName());
				try {
					// read the property time
					long cardSeconds = Long.parseLong(cmsObject.readPropertyObject(currentImage, "greetingCardTransmitTime", false).getValue()) / 1000;
					if (cardSeconds <= currentSeconds) {
						cmsObject.lockResource(currentImage.getRootPath());
						cmsObject.moveResource(currentImage.getRootPath(), newUrl);
						cmsObject.unlockResource(currentImage.getRootPath());
						cmsObject.publishResource(newUrl);
						cmsObject.publishResource(currentImage.getRootPath());
						CmsFile newRes = cmsObject.readFile(newUrl);
						elementsToSend.add(newRes);
					}
				} catch (NumberFormatException nfex) {
					OpenCms.getLog(this.getClass()).error("Couldn't send one of the mails (" + imageUrl + ")", nfex);
				}
				
			}
			if (online) {
				cmsObject.getRequestContext().setCurrentProject(cmsObject.readProject(CmsProject.ONLINE_PROJECT_ID));
			}
			
		} catch (CmsException ex) {
			OpenCms.getLog(this.getClass()).error("", ex);
		} catch (Exception ex) {
			OpenCms.getLog(this.getClass()).error("", ex);
		}
		return elementsToSend;
	}
	
	/**
	 * These method is from the I_CmsScheduledJob interface. At the constructor of this
	 * class the schedule job is written into the opencms system. The launch method is
	 * called dependent on the cron job defnition.
	 *
	 * @param cmsObject The cmsobject to deal with.
	 * @param map The parameters of the opencms.
	 * @throws java.lang.Exception
	 * @return The log to be written at the opencms log.
	 */
	public String launch(CmsObject cmsObject, Map map) throws Exception {
		log.debug("Launch the scheduled job. Initialize the FindMaster with the master name : "
			+ (String)map.get("MasterName"));
		FindMaster findMaster = new FindMaster( (String)map.get("MasterName"));
		if (findMaster.amIMaster()) {
			int amountSend = 0;
			long currentTime = System.currentTimeMillis();
			List toSend = getElementsToSend(currentTime, cmsObject);
			Iterator toSendIterator = toSend.iterator();
			// iterate over all elements and send them
			while (toSendIterator.hasNext()) {
				CmsFile currentImage = (CmsFile) toSendIterator.next();
				boolean sendImage = false;
				if ("true".equals(cmsObject.readPropertyObject(currentImage, "greetingCardSendImage", false).getValue())) {
					sendImage = true;
				}
				String mailTo = cmsObject.readPropertyObject(currentImage, "greetingCardReceiverAddress", false).getValue();
				sendMail(cmsObject.readPropertyObject(currentImage, "greetingCardAuthorName", false).getValue(),
					cmsObject.readPropertyObject(currentImage, "greetingCardAuthorAddress", false).getValue(),
					cmsObject.readPropertyObject(currentImage, "greetingCardReceiverName", false).getValue(),
					mailTo,
					cmsObject.readPropertyObject(currentImage, "greetingCardSubject", false).getValue(),
					currentImage,
					cmsObject.readPropertyObject(currentImage, "greetingCardArchiveUrl", false).getValue(),
					cmsObject,
					"0",
					sendImage);
				amountSend++;
			}
			
			return LOG + amountSend;
		} else {
			return "This is not the master so won't launch.";
		}
	}
	
	private static void sendMail(final String from, final String fromName, final String to, final String toName,
		final String subject, final String content) throws MessagingException, UnsupportedEncodingException {
		
		Session session = TransmitMail.getSession();
		final MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(from, fromName));
		mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(to, toName));
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(content, "text/html");
		// we don't send in a new Thread so that we get the Exception
		Transport.send(mimeMessage);
	}
	
	private static void sendMultipartMail(final String from, final String fromName, final String to, final String toName,
		final String subject, final String content, final CmsVfsDataSource ds, final String filename) throws MessagingException, UnsupportedEncodingException {
		
		
		Session session = TransmitMail.getSession();
		MimeMultipart multipart = new MimeMultipart();
		MimeBodyPart html = new MimeBodyPart();
		html.setContent(content, "text/html");
		html.setHeader("MIME-Version" , "1.0");
		html.setHeader("Content-Type" , html.getContentType());
		multipart.addBodyPart(html);
		
		BodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setDataHandler(new DataHandler(ds));
		messageBodyPart.setFileName(filename);
		multipart.addBodyPart(messageBodyPart);
		
		final MimeMessage message = new MimeMessage(session);
		message.setContent(multipart);
		message.setFrom(new InternetAddress(from, fromName));
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(to, toName));
		message.setSubject(subject);
		
		// we don't send in a new Thread so that we get the Exception
		Transport.send(message);
	}
	
	
	private static Session getSession() {
		final CmsMailHost host = OpenCms.getSystemInfo().getMailSettings().getDefaultMailHost();
		Properties props = new Properties();
		props.put("mail.transport.protocol", host.getProtocol());
		props.put("mail.smtp.host", host.getHostname());
		props.put("mail.smtp.auth", host.isAuthenticating());
		
		Authenticator authenticator = new Authenticator() {
			public PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(host.getUsername(), host.getPassword());
			}
		};
		
		return Session.getInstance(props, authenticator);
		
	}
}
