/*
 * This file is part of the Synyx Greetingcard module for OpenCms.
 *
 * Copyright (c) 2007 Synyx GmbH & Co.KG (http://www.synyx.de)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.synyx.greetingcard;

import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsProject;
import org.opencms.file.CmsProperty;
import org.opencms.file.CmsResource;
import org.opencms.file.types.CmsResourceTypeImage;
import org.opencms.jsp.CmsJspActionElement;
import org.opencms.main.CmsException;
import org.opencms.main.OpenCms;

/**
 * Convenience Methods for use in GreetingCard Module
 * @author Rainer Steinegger, Synyx GmbH & Co. KG
 * @author Florian Hopf, Synyx GmbH & Co. KG
 */
public class GreetingCardHelper {
    
    private static final Map<String, String> PROTOCOLS = new HashMap<String, String>();
    
    /** Creates a new instance of GreetingCardHelper */
    private GreetingCardHelper() {
    }
    
    static {
        PROTOCOLS.put("HTTP/1.1", "http://");
        PROTOCOLS.put("HTTPS/1.1", "https://");
    }
    
    /**
     * This method returns the last day of the current month.
     * @param searchedMonth The month for which the amount of days are searched.
     * @return The amount of days of this month.
     */
    public static final int getAmountDays(final int searchedMonth, final int searchedYear) {
        int temp = -1;
        switch (searchedMonth) {
            case 1: temp = 31;
            break;
            case 2: temp = getDaysOfFebruary(searchedYear);
            break;
            case 3: temp = 31;
            break;
            case 5: temp = 31;
            break;
            case 7: temp = 31;
            break;
            case 8: temp = 31;
            break;
            case 10: temp = 31;
            break;
            case 12: temp = 31;
            break;
            default: temp = 30;
        }
        return temp;
    }

    /**
     * This method returns the amount of days from february.
     * @return The amount of days from february.
     * @param year the year for that the days in february are asked
     */
    public static final int getDaysOfFebruary(final int year) {
        int days = 28;
        if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)) {
            days = days + 1;
        }
        return days;
    }
    
    /**
     * Reads a List<String> of all domains configured in the whitelist.
     * 
     */
    public static synchronized final List<String> getWhitelist(final String address, final String user, final String pass,
            final String tableField, final String tableName) throws SQLException, ClassNotFoundException {
        List<String> domains = new ArrayList<String>();
        Connection conn = DriverManager.getConnection(address, user, pass);   
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM " + tableName);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()) {
                domains.add(rs.getString(tableField));
            }   
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return domains;
    }
    
    public static synchronized final boolean isInternal(final String eMail, final String address,
            final String tableField, final String tableName, final String user, final String pass) {
        boolean internal = false;
        if (eMail.indexOf("@") != -1) {
            String domain = eMail.split("@")[1];
            Connection conn = null;
            try {
                conn = DriverManager.getConnection(address, user, pass); 
                if (conn != null) {
                        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM " + tableName + " WHERE " + tableField + "=?");
                        stmt.setString(1, domain);
                        ResultSet rs = stmt.executeQuery();
                        // it is internal if there is at least one result
                        internal = rs.next();
                } else {
                    OpenCms.getLog(GreetingCardHelper.class).debug("Couldn't connect to whitelist, defaulting to attaching image");
                    internal = false;
                }
            } catch (SQLException ex) {
              internal = false;
            } finally {
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (SQLException ex) {
                        OpenCms.getLog(GreetingCardHelper.class).error("Error trying to close the connection", ex);
                    }
                }
            }
        }
        return internal;
    }
    
    /**
     * Returns the full request path including protocol, server and port.
     * @param request the ServletRequest 
     * @param path the path to append to the server address
     * @return the full path
     */
    public static final String getServerPath(final ServletRequest request, final String path) {
        StringBuilder builder = new StringBuilder();
        builder.append(PROTOCOLS.get(request.getProtocol()));
        builder.append(request.getServerName());
        builder.append(':');
        builder.append(request.getServerPort());
        builder.append(path);

        return builder.toString();
    }
    
    /**
     * Returns the full request path including protocol, server, port, context and opencms-servlet.
     * @param request the ServletRequest
     * @param response the ServletResponse
     * @param pageContext
     * @param rootPath
     */
    public static final String getServerContextPath(final HttpServletRequest request,
            final HttpServletResponse response, final PageContext context, final String rootPath) {
        CmsJspActionElement action = new CmsJspActionElement(context, request, response);
        return GreetingCardHelper.getServerPath(request, action.link(rootPath));
    }
    
    /**
     * Returns the link for a resource in VFS.
     */
/*    public static final String getLink(final HttpServletRequest request, 
            final HttpServletResponse response, final PageContext context, final String path) {
        CmsJspActionElement action = new CmsJspActionElement(context, request, response);
        return action.link(path);
    }*/
    
    /**
     * Writes the given image to the VFS.
     * @param cms the CmsObject 
     * @param image the created RenderedImage
     * @param path the path in VFS to write to 
     * @throws org.opencms.main.CmsException if project can't be changed or if file can't be created
     * @throws java.io.IOException if writing the image data fails
     * @throws java.lang.Exception if publishing the resource fails
     */
    public static final void writeImage(CmsObject cms, RenderedImage image, String path, boolean isInternal) throws CmsException, IOException, Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(image, "png", out);
        boolean wasOnline = setProjectOffline(cms);
        CmsResource res = cms.createResource(path + ".png", CmsResourceTypeImage.getStaticTypeId(), out.toByteArray(), null);
        cms.writePropertyObject(path + ".png", new CmsProperty("greetingCardInternal", String.valueOf(isInternal), String.valueOf(isInternal)));
        cms.unlockResource(path + ".png");
        cms.publishResource(path + ".png");
        if (wasOnline) {
            cms.getRequestContext().setCurrentProject(cms.readProject(CmsProject.ONLINE_PROJECT_ID));
        }
    }
    
    /**
     * Sets the project to offline if neccessary.
     * @param cms the CmsObject
     * @throws org.opencms.main.CmsException if setting to offline fails
     * @return whether the project was the online project 
     */
    public static final boolean setProjectOffline(final CmsObject cms) throws CmsException {
        boolean online = cms.getRequestContext().currentProject().isOnlineProject();
        if (online) {
            cms.getRequestContext().setCurrentProject(cms.readProject("Offline"));
        }
        return online;
    }
    
}
