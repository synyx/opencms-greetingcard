/*
 * This file is part of the Synyx Greetingcard module for OpenCms.
 *
 * Copyright (c) 2007 Synyx GmbH & Co.KG (http://www.synyx.de)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.synyx.greetingcard;

import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import org.opencms.file.CmsObject;
import org.opencms.jsp.CmsJspActionElement;
import org.opencms.jsp.CmsJspTagContentLoad;
import org.opencms.jsp.CmsJspTagContentLoop;
import org.opencms.jsp.CmsJspXmlContentBean;

/**
 *
 * @author Florian Hopf, Synyx GmbH & Co. KG
 */
public class DataInputBean {
    
    private CmsJspXmlContentBean content;
    private Locale locale;
    private boolean useWhitelist;
    
    private String fontColor;
    
    private String authorName = "";
    private String authorAddress = "";
    private String receiverName = "";
    private String receiverAddress = "";
    private String subject = "Eine Gru&szlig;karte f&uuml;r Sie";
    private String [] text = null;
    private String errorMessage;
    
    private List domains;
    
    private String resourceName;
    
    /** Creates a new instance of DataInputBean */
    public DataInputBean() {
    }
    
    public void init(PageContext context, HttpServletRequest request, HttpServletResponse response) throws JspException, SQLException, ClassNotFoundException {
        content = new CmsJspXmlContentBean(context, request, response);
        CmsObject cms = getContent().getCmsObject();
        locale = cms.getRequestContext().getLocale();
        CmsJspTagContentLoad configurationContentList = (CmsJspTagContentLoad) getContent().contentload("singleFile",
                cms.getRequestContext().removeSiteRoot("/sites/default/greetingcards/configuration"), false);
        configurationContentList.hasMoreContent();
        // get all text fields of the xml-file
        CmsJspTagContentLoop databaseContentList = (CmsJspTagContentLoop)getContent().contentloop(configurationContentList, "Database");
        databaseContentList.hasMoreContent();
        String useWhiteList = getContent().contentshow(databaseContentList, "UseWhiteList", getLocale());
        useWhitelist = "true".equalsIgnoreCase(useWhiteList);
        
        // initialize the default name of the current folder
        resourceName = "fault";
        if (request.getParameter("greetingcard_fileName") != null) {
            // if there is a request of a selected folder, the new name of the current folder is set
            resourceName = request.getParameter("greetingcard_fileName");
        } 
        fontColor = getContent().getContent(resourceName, "FontColor", getLocale());
        
        if (request.getAttribute("errorMessage") != null) {
            errorMessage= (String)request.getAttribute("errorMessage");
            authorName = request.getParameter("author_name");
            authorAddress = request.getParameter("author_address");
            receiverName = request.getParameter("receiver_name");
            receiverAddress = request.getParameter("receiver_address");
            subject = request.getParameter("subject");
            text = new String [] {request.getParameter("text0")};
        }    

        if (useWhitelist) {
             // The name used for the connection to the database.
             String address = content.contentshow(databaseContentList, "DatabaseUrl", locale);
             String tableName = content.contentshow(databaseContentList, "TableName", locale);            
             String tableField = content.contentshow(databaseContentList, "ColumnName", locale);    
             String usr = content.contentshow(databaseContentList, "DatabaseUser", locale);      
             String pass = content.contentshow(databaseContentList, "DatabasePassword", locale);      

             domains = GreetingCardHelper.getWhitelist(address, usr, pass, tableField, tableName);

        }
        
    }
    
    public boolean isUseWhitelist() {
        return useWhitelist;
    }
    
    public String getFontColor() {
        return fontColor;
    }

    public CmsJspXmlContentBean getContent() {
        return content;
    }

    public Locale getLocale() {
        return locale;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getAuthorAddress() {
        return authorAddress;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public String getReceiverAddress() {
        return receiverAddress;
    }

    public String getSubject() {
        return subject;
    }

    public String[] getText() {
        return text;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
    
    public List getDomains() {
        return domains;
    }

    public String getResourceName() {
        return resourceName;
    }
}
