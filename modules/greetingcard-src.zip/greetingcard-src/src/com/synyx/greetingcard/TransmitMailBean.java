/*
 * This file is part of the Synyx Greetingcard module for OpenCms.
 *
 * Copyright (c) 2007 Synyx GmbH & Co.KG (http://www.synyx.de)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.synyx.greetingcard;

import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.jsp.CmsJspActionElement;
import org.opencms.jsp.CmsJspTagContentLoad;
import org.opencms.jsp.CmsJspTagContentLoop;
import org.opencms.jsp.CmsJspXmlContentBean;
import org.opencms.main.CmsException;

/**
 *
 * @author Florian Hopf, Synyx GmbH & Co. KG
 */
public class TransmitMailBean {

    private boolean transmitted;
    
    public void init(PageContext context, HttpServletRequest request, HttpServletResponse response) throws CmsException, JspException {
        CmsJspXmlContentBean content = new CmsJspXmlContentBean(context, request, response);
        CmsObject cmsObject = content.getCmsObject();
        Locale currentLocale = cmsObject.getRequestContext().getLocale();

        //get the parameters from the request
        String author_name = request.getParameter("author_name");
        String author_address = request.getParameter("author_address");
        String receiver_name = request.getParameter("receiver_name");
        String receiver_address = request.getParameter("receiver_address");
        String subject = request.getParameter("subject"); 
        String transmit_date = request.getParameter("transmit_date");
        String image_url = request.getParameter("image_url");

        CmsJspTagContentLoad configurationContentList = (CmsJspTagContentLoad) content.contentload("singleFile", 
                cmsObject.getRequestContext().removeSiteRoot("/sites/default/greetingcards/configuration"), false);
        configurationContentList.hasMoreContent();
        // get all text fields of the xml-file              
        CmsJspTagContentLoop databaseContentList = (CmsJspTagContentLoop)content.contentloop(configurationContentList, "Database");
        databaseContentList.hasMoreContent();

         // The name used for the connection to the database.
         String address = content.contentshow(databaseContentList, "DatabaseUrl", currentLocale);
         String tableName = content.contentshow(databaseContentList, "TableName", currentLocale);            
         String tableField = content.contentshow(databaseContentList, "ColumnName", currentLocale);    
         String usr = content.contentshow(databaseContentList, "DatabaseUser", currentLocale);      
         String pass = content.contentshow(databaseContentList, "DatabasePassword", currentLocale);      
         String useWhiteList = content.contentshow(databaseContentList, "UseWhiteList", currentLocale);   

         boolean sendImage = !GreetingCardHelper.isInternal(receiver_address, address, tableField, tableName, usr, pass);

        // get the image as file
        CmsFile imageAsFile = cmsObject.readFile(image_url);
        // get url of the server for sending the url of the generated image
        String serverUrl = GreetingCardHelper.getServerContextPath(request, response, context, cmsObject.getRequestContext().removeSiteRoot(imageAsFile.getRootPath())); 
        // send the mail with the TransmitMail-class       
        transmitted = TransmitMail.sendMail(author_name, author_address, receiver_name, receiver_address, subject, imageAsFile, serverUrl, cmsObject, transmit_date, sendImage);
        
    }
    
    public boolean isTransmitted() {
        return transmitted;
    }
    
}
